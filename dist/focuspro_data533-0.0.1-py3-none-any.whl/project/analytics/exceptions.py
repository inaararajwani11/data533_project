class ReportExportError(Exception):
    """Raised when exporting analytics reports fails."""

